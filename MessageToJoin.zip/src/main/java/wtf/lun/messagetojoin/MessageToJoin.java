package wtf.lun.messagetojoin;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

public final class MessageToJoin extends JavaPlugin implements Listener {

    private FileConfiguration config;

    @Override
    public void onEnable() {
        // Регистрация обработчика событий
        Bukkit.getPluginManager().registerEvents(this, this);

        // Загрузка конфига
        saveDefaultConfig();
        config = getConfig();
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();

        // Получаем сообщение из конфига и заменяем цветовые коды
        String message = ChatColor.translateAlternateColorCodes('&', config.getString("join-message", "&aДобро пожаловать на сервер!"));
        player.sendMessage(message);
    }
}
